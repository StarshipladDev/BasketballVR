﻿using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using UnityEngine;

public class BallAbove0 : MonoBehaviour
{
    int i = 0;
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        i++;
        if (i > 10)
        {
            i = 0;
            if (transform.position.y < 0)
            {
                transform.position = new Vector3(0, 1,0);
            }
        }
    }
}
